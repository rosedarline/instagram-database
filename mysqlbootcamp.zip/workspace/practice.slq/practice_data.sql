SELECT COUNT(*) FROM books;

SELECT released_year, COUNT(*)
FROM books
GROUP BY released_year;

SELECT SUM(stock_quantity)
FROM books;


SELECT author_fname, author_lname,
    AVG(released_year)
FROM books
GROUP BY author_lname, author_fname;


SELECT pages,
    CONCAT(author_fname, ' ', author_lname)
FROM books
GROUP BY pages DESC;


SELECT released_year AS year,
    COUNT(*) AS '# books',
    AVG(pages) AS 'avg pages'
FROM books
GROUP BY released_year;

CREATE TABLE peps (
name VARCHAR (100),
birthdate DATE,
birthtime TIME,
birthdt DATETIME
);

INSERT INTO peps (name, birthdate, birthtime, birthdt)
VALUES ('Larry', '1943-12-25', '04:10:42', '1943-12-25 04:10:42');


CREATE TABLE inventory (
    item_name VARCHAR,
    price DECIMAL(8,2),
    quantity INT
);

SELECT DATE_FORMAT(CURDATE(), '%m/%d/%y');

SELECT DATE_FORMAT(NOW(), '%M %D at %h:%i');

CREATE TABLE tweets (
        content VARCHAR(140),
        Username VARCHAR(20),
        creat_at TIMESTAMP DEFAULT NOW()
);        

INSERT INTO tweets (content, Username) 
VALUES ('this is my first tweet', 'mycatleo;

SELECT DAYNAME(NOW());



SELECT 10 != 10;                            false
SELECT 15 > 14 && 99 - 5 <= 94;             true
SELECT 1 IN (5,3) || 9 BETWEEN 8 AND 10;    true


SELECT title, released_year FROM books
WHERE released_year < 1980;


SELECT title, author_lname
FROM books
WHERE author_lname = 'Eggers'
    OR author_lname = 'Chabon';


SELECT title, author_lname, released_year
FROM books
WHERE author_lname = 'Lahiri' AND released_year > 2000;


SELECT title, pages
FROM books     
WHERE pages BETWEEN 100 AND 200;


SELECT title, author_lname
FROM books
WHERE author_lname LIKE 'C%' OR 
    author_lname LIKE S%;


SELECT title, author_lname,
    CASE
        WHEN title LIKE '%stories%' THEN 'Short Stories'
        WHEN title = 'Just Kids' OR title = 'A Heartbreqking Work of Staggering Genuis' THEN 'Memoir'
        ELSE 'Novel'
    END AS TYPE
FROM books;    


SELECT author_fname, author_lname,
    CASE
        WHEN COUNT(*) = 1 THEN '1 book'
        ELSE CONCAT(COUNT(*), ' books')
    END AS COUNT 
FROM books
GROUP BY author_lname, author_fname;
